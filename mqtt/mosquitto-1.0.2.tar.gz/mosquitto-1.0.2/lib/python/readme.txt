This directory contains two Python modules, mosquitto.py and mosquitto-wrap.py.

mosquitto.py is a pure Python implementation of an MQTT client.
mosquitto-wrap.py is a Python wrapper around the mosquitto C client library.

mosquitto-wrap.py is more mature that mosquitto.py

At some point, mosquitto.py will become the only offering but it needs a lot of
improvement first.
